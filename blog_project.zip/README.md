# My Blog Project
A simple blog with Flask, SQLite, HTML, and CSS.

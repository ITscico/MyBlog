from flask import Flask, render_template, request, redirect, url_for, send_from_directory
import sqlite3, os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

# Create DB
def init_db():
    with sqlite3.connect("database.db") as con:
        cur = con.cursor()
        cur.execute("CREATE TABLE IF NOT EXISTS posts (id INTEGER PRIMARY KEY, title TEXT, content TEXT, file TEXT)")
        cur.execute("CREATE TABLE IF NOT EXISTS comments (id INTEGER PRIMARY KEY, post_id INTEGER, content TEXT)")
    con.close()

@app.route('/')
def index():
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    cur.execute("SELECT * FROM posts")
    posts = cur.fetchall()
    con.close()
    return render_template("index.html", posts=posts)

@app.route('/post/<int:post_id>', methods=["GET", "POST"])
def post(post_id):
    con = sqlite3.connect("database.db")
    cur = con.cursor()
    if request.method == "POST":
        comment = request.form['comment']
        cur.execute("INSERT INTO comments (post_id, content) VALUES (?, ?)", (post_id, comment))
        con.commit()
    cur.execute("SELECT * FROM posts WHERE id=?", (post_id,))
    post = cur.fetchone()
    cur.execute("SELECT * FROM comments WHERE post_id=?", (post_id,))
    comments = cur.fetchall()
    con.close()
    return render_template("article.html", post=post, comments=comments)

@app.route('/new', methods=["GET", "POST"])
def new_post():
    if request.method == "POST":
        title = request.form['title']
        content = request.form['content']
        file = request.files['file']
        filename = None
        if file and file.filename:
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        con = sqlite3.connect("database.db")
        cur = con.cursor()
        cur.execute("INSERT INTO posts (title, content, file) VALUES (?, ?, ?)", (title, content, filename))
        con.commit()
        con.close()
        return redirect(url_for('index'))
    return render_template("new_post.html")

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
